// Shared components for all pages
const NAV_HTML = `
<nav>
  <a href="index.html" class="nav-logo">
    <img src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=80&h=80&fit=crop&crop=center" alt="Coffea Logo" />
    <div class="nav-logo-text">
      <span>COFFEA</span>
      <span>CHHINDWARA</span>
    </div>
  </a>
  <ul class="nav-links">
    <li><a href="index.html">Home</a></li>
    <li><a href="menu.html">Menu</a></li>
    <li><a href="about.html">About Us</a></li>
    <li><a href="gallery.html">Gallery</a></li>
    <li><a href="franchise.html">Franchise</a></li>
    <li><a href="contact.html">Contact Us</a></li>
  </ul>
  <div style="display:flex;align-items:center;gap:15px;">
    <a href="menu.html" class="btn-order" style="position:relative;">
      🛒 Order Now
      <span class="cart-count" style="position:absolute;top:-8px;right:-8px;background:#c9a84c;color:white;border-radius:50%;width:18px;height:18px;font-size:0.65rem;font-weight:700;display:none;align-items:center;justify-content:center;">0</span>
    </a>
  </div>
  <button class="hamburger" id="hamburger" aria-label="Menu">
    <span></span><span></span><span></span>
  </button>
</nav>
<div class="mobile-nav" id="mobileNav">
  <a href="index.html">🏠 Home</a>
  <a href="menu.html">☕ Menu</a>
  <a href="about.html">👋 About Us</a>
  <a href="gallery.html">📷 Gallery</a>
  <a href="franchise.html">🤝 Franchise</a>
  <a href="contact.html">📞 Contact Us</a>
  <a href="menu.html" style="color:#5db347;font-weight:700;">🛒 Order Now</a>
</div>
`;

const FOOTER_HTML = `
<footer>
  <div class="footer-grid">
    <div class="footer-brand">
      <a href="index.html" class="footer-logo-wrap">
        <img src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=80&h=80&fit=crop" alt="Coffea Logo" />
        <div class="footer-logo-text">
          <strong>COFFEA</strong>
          <small>CHHINDWARA</small>
        </div>
      </a>
      <p class="footer-tagline">
        Brewed to perfection ☕<br>
        Sip · Relax · Repeat<br>
        Good Vibes Guaranteed
      </p>
      <div class="footer-socials">
        <a href="#" class="social-icon" title="Instagram">📸</a>
        <a href="#" class="social-icon" title="Facebook">👍</a>
        <a href="#" class="social-icon" title="WhatsApp">💬</a>
        <a href="#" class="social-icon" title="Twitter">🐦</a>
      </div>
    </div>
    <div class="footer-col">
      <h4>Quick Links</h4>
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="menu.html">Menu</a></li>
        <li><a href="about.html">About Us</a></li>
        <li><a href="gallery.html">Gallery</a></li>
        <li><a href="franchise.html">Franchise</a></li>
        <li><a href="contact.html">Contact Us</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Our Menu</h4>
      <ul>
        <li><a href="menu.html#hot">Hot Beverages</a></li>
        <li><a href="menu.html#cold">Cold Beverages</a></li>
        <li><a href="menu.html#frappe">Frappes</a></li>
        <li><a href="menu.html#snacks">Snacks</a></li>
        <li><a href="menu.html#desserts">Desserts</a></li>
        <li><a href="menu.html#combos">Combos</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Contact Us</h4>
      <div class="footer-contact-item">
        <span>📍</span>
        <span>4th Flr, Diwedi Tower, Parasia Rd, Near by Claris Hospital, Vishnu Nagar, Chhindwara (M.P.)</span>
      </div>
      <div class="footer-contact-item">
        <span>📞</span>
        <span>+91 88786 43210</span>
      </div>
      <div class="footer-contact-item">
        <span>✉️</span>
        <span>hello@coffeachhindwara.com</span>
      </div>
      <div class="footer-contact-item">
        <span>🕐</span>
        <span>Mon – Sun: 9:00 AM – 10:00 PM</span>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <p>© 2024 Coffea Chhindwara. All Rights Reserved.</p>
    <p>Designed with ❤️ by <span>Saher</span></p>
  </div>
</footer>
`;

document.addEventListener('DOMContentLoaded', () => {
  const navContainer = document.getElementById('nav-container');
  const footerContainer = document.getElementById('footer-container');
  if (navContainer) navContainer.innerHTML = NAV_HTML;
  if (footerContainer) footerContainer.innerHTML = FOOTER_HTML;
});
