// ===== NAVIGATION =====
function initNav() {
  const hamburger = document.getElementById('hamburger');
  const mobileNav = document.getElementById('mobileNav');
  
  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => {
      mobileNav.classList.toggle('open');
    });
    
    document.addEventListener('click', (e) => {
      if (!hamburger.contains(e.target) && !mobileNav.contains(e.target)) {
        mobileNav.classList.remove('open');
      }
    });
  }

  // Active link highlight
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  const links = document.querySelectorAll('.nav-links a, .mobile-nav a');
  links.forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      link.classList.add('active');
    }
  });
}

// ===== CART =====
let cart = JSON.parse(localStorage.getItem('coffeaCart') || '[]');

function updateCartCount() {
  const count = cart.reduce((sum, item) => sum + item.qty, 0);
  const badges = document.querySelectorAll('.cart-count');
  badges.forEach(b => {
    b.textContent = count;
    b.style.display = count > 0 ? 'flex' : 'none';
  });
}

function addToCart(name, price) {
  const existing = cart.find(i => i.name === name);
  if (existing) {
    existing.qty++;
  } else {
    cart.push({ name, price, qty: 1 });
  }
  localStorage.setItem('coffeaCart', JSON.stringify(cart));
  updateCartCount();
  showToast(`${name} added to cart! ☕`);
}

// ===== TOAST =====
function showToast(msg) {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();
  
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = msg;
  toast.style.cssText = `
    position: fixed; bottom: 30px; right: 30px; z-index: 9999;
    background: #2d6a2f; color: white; padding: 14px 24px;
    border-radius: 12px; font-family: Poppins, sans-serif;
    font-size: 0.88rem; font-weight: 500;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    animation: slideInToast 0.4s ease;
  `;
  document.body.appendChild(toast);
  setTimeout(() => toast.style.opacity = '0', 2500);
  setTimeout(() => toast.remove(), 3000);
}

// ===== MENU TABS (menu page) =====
function initMenuTabs() {
  const tabs = document.querySelectorAll('.tab-btn');
  const sections = document.querySelectorAll('.menu-cat-section');
  
  if (!tabs.length) return;
  
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.dataset.tab;
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      if (target === 'all') {
        sections.forEach(s => s.style.display = 'block');
      } else {
        sections.forEach(s => {
          s.style.display = s.dataset.cat === target ? 'block' : 'none';
        });
      }
    });
  });
}

// ===== CONTACT FORM =====
function initContactForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;
  
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    showToast('Message sent! We\'ll get back to you soon. 😊');
    form.reset();
  });
}

// ===== LIGHTBOX (gallery) =====
function initGallery() {
  const items = document.querySelectorAll('.gallery-item');
  if (!items.length) return;
  
  items.forEach(item => {
    item.addEventListener('click', () => {
      const img = item.querySelector('img');
      if (!img) return;
      
      const overlay = document.createElement('div');
      overlay.style.cssText = `
        position: fixed; inset: 0; z-index: 9999;
        background: rgba(0,0,0,0.9);
        display: flex; align-items: center; justify-content: center;
        cursor: pointer; padding: 20px;
      `;
      const imgEl = document.createElement('img');
      imgEl.src = img.src;
      imgEl.style.cssText = 'max-width: 90vw; max-height: 90vh; border-radius: 12px; object-fit: contain;';
      overlay.appendChild(imgEl);
      document.body.appendChild(overlay);
      overlay.addEventListener('click', () => overlay.remove());
    });
  });
}

// ===== SCROLL ANIMATIONS =====
function initScrollAnim() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, { threshold: 0.1 });
  
  document.querySelectorAll('.menu-card, .franchise-card, .contact-info-card, .contact-form-wrap').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
  });
}

// ===== FRANCHISE FORM =====
function initFranchiseForm() {
  const form = document.getElementById('franchiseForm');
  if (!form) return;
  form.addEventListener('submit', e => {
    e.preventDefault();
    showToast('Application received! Our team will contact you within 48 hours. 🎉');
    form.reset();
  });
}

// Toast animation CSS
const style = document.createElement('style');
style.textContent = `
  @keyframes slideInToast {
    from { transform: translateX(100px); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
`;
document.head.appendChild(style);

// Init all
document.addEventListener('DOMContentLoaded', () => {
  initNav();
  updateCartCount();
  initMenuTabs();
  initContactForm();
  initGallery();
  initScrollAnim();
  initFranchiseForm();
});
